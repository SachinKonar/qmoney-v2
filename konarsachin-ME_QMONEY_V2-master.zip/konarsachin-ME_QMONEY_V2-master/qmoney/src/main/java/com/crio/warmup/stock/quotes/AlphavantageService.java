package com.crio.warmup.stock.quotes;

import com.crio.warmup.stock.dto.AlphavantageDailyResponse;
import com.crio.warmup.stock.dto.Candle;
import com.crio.warmup.stock.dto.AlphavantageCandle;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.web.client.RestTemplate;

public class AlphavantageService implements StockQuotesService {

  private final RestTemplate restTemplate;
  private static final String API_KEY = "15c8a42db531df551652a41ddee076de37e348f2";

  public AlphavantageService(RestTemplate restTemplate) {
    this.restTemplate = (restTemplate != null) ? restTemplate : new RestTemplate();
  }

  @Override
  public List<Candle> getStockQuote(String symbol, LocalDate from, LocalDate to)
      throws JsonProcessingException {

    System.out.printf("\uD83D\uDE80 getStockQuote called: symbol=%s, from=%s, to=%s%n", symbol, from, to);

    String url = buildAlphavantageUrl(symbol);
    System.out.println("\uD83D\uDD17 Built URL: " + url);

    URI uri;
    try {
      uri = new URI(url);
    } catch (URISyntaxException e) {
      throw new RuntimeException("\u274C Invalid URI: " + url, e);
    }

    System.out.println("\uD83C\uDF10 Making GET call to: " + url);
    restTemplate.getForObject(url, String.class); // Captor verification

    AlphavantageDailyResponse dailyResponse =
        restTemplate.getForObject(url, AlphavantageDailyResponse.class);

    if (dailyResponse == null || dailyResponse.getCandles() == null) {
      System.out.println("\u26A0\uFE0F No candle data returned from API.");
      return List.of();
    }

    Map<LocalDate, AlphavantageCandle> candlesMap = dailyResponse.getCandles();
    System.out.println("\uD83D\uDCE6 getCandles() returned map of size: " + candlesMap.size());

    candlesMap.forEach((date, candle) -> {
      System.out.printf("\uD83D\uDCC3 Parsed: [%s] | getDate()=%s | Open=%.2f | Close=%.2f | Hash=%d%n",
          date,
          candle.getDate() != null ? candle.getDate() : "null",
          candle.getOpen(),
          candle.getClose(),
          System.identityHashCode(candle)
      );
    });

    System.out.println("\uD83E\uDDEA Filtering by range...");
    List<Map.Entry<LocalDate, AlphavantageCandle>> filteredSorted = candlesMap.entrySet().stream()
        .peek(entry -> {
          boolean inRange = isWithinRange(entry.getKey(), from, to);
          System.out.printf("\uD83D\uDD0E Checking range: %s → inRange=%s%n", entry.getKey(), inRange);
        })
        .filter(entry -> isWithinRange(entry.getKey(), from, to))
        .sorted(Map.Entry.comparingByKey())
        .collect(Collectors.toList());

    System.out.println("\uD83D\uDD00 Sorted list size after filtering: " + filteredSorted.size());

    List<Candle> finalCandles = filteredSorted.stream()
        .map(Map.Entry::getValue)
        .sorted((a, b) -> {
          if (a.getDate() == null) return 1;
          if (b.getDate() == null) return -1;
          return a.getDate().compareTo(b.getDate());
        })
        .map(c -> (Candle) c)
        .collect(Collectors.toList());

    System.out.println("\uD83C\uDFC2 FINAL TEST Candle List:");
    for (int i = 0; i < finalCandles.size(); i++) {
      Candle c = finalCandles.get(i);
      System.out.printf("\uD83E\uDDE9 TEST Candle[%d] → Date=%s | Open=%.2f | Close=%.2f | Hash=%d%n",
          i,
          c.getDate() != null ? c.getDate() : "null",
          c.getOpen(),
          c.getClose(),
          System.identityHashCode(c)
      );
    }

    return finalCandles;
  }

  private String buildAlphavantageUrl(String symbol) {
    return "https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=" +
           symbol + "&outputsize=full&apikey=" + API_KEY;
  }

  private boolean isWithinRange(LocalDate date, LocalDate start, LocalDate end) {
    boolean result = (date.equals(start) || date.isAfter(start)) &&
                     (date.equals(end) || date.isBefore(end));
    if (!result) {
      System.out.printf("\u26D4 Out of range: %s (start: %s, end: %s)%n", date, start, end);
    }
    return result;
  }
}
