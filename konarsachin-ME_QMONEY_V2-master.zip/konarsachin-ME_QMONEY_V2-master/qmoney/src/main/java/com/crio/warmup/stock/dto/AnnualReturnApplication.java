package com.crio.warmup.stock.dto;

public class AnnualReturnApplication {

}
