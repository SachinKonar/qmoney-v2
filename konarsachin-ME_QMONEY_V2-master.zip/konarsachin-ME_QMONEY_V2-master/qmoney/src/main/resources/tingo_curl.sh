curl https://api.tiingo.com/tiingo/daily/MCD/prices?token=2f67393bdd2faf29ebbc2c5abe0570deb737dd82
curl https://api.tiingo.com/tiingo/daily/qsr/prices?token=2f67393bdd2faf29ebbc2c5abe0570deb737dd82
curl https://api.tiingo.com/tiingo/daily/wen/prices?token=2f67393bdd2faf29ebbc2c5abe0570deb737dd82