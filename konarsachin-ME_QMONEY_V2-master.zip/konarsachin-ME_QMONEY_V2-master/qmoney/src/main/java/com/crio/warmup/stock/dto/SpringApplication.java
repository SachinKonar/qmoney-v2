package com.crio.warmup.stock.dto;

public class SpringApplication {

    public static void run(Class<AnnualReturnApplication> class1, String[] args) {}

}
