
package com.crio.warmup.stock.portfolio;

import static java.time.temporal.ChronoUnit.DAYS;
import static java.time.temporal.ChronoUnit.SECONDS;
import com.crio.warmup.stock.PortfolioManagerApplication;
import com.crio.warmup.stock.dto.AnnualizedReturn;
import com.crio.warmup.stock.dto.Candle;
import com.crio.warmup.stock.dto.PortfolioTrade;
import com.crio.warmup.stock.dto.TiingoCandle;
import com.crio.warmup.stock.exception.StockQuoteServiceException;
import com.crio.warmup.stock.quotes.StockQuoteServiceFactory;
import com.crio.warmup.stock.quotes.StockQuotesService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

public class PortfolioManagerImpl implements PortfolioManager {

  private String token;
  //private RestTemplate restTemplate;
  private StockQuotesService stockQuotesService ;


  protected PortfolioManagerImpl(RestTemplate restTemplate) {
    //this.restTemplate = restTemplate;
    this.stockQuotesService = StockQuoteServiceFactory.INSTANCE.getService("", new RestTemplate());    
  }

  protected PortfolioManagerImpl (String provider, RestTemplate restTemplate) {    
    this.stockQuotesService = StockQuoteServiceFactory.INSTANCE.getService(provider, new RestTemplate());
  }

  // Caution: Do not delete or modify the constructor, or else your build will break!
  // This is absolutely necessary for backward compatibility
  protected PortfolioManagerImpl(StockQuotesService stockQuotesService) {
    this.stockQuotesService  = stockQuotesService;
  }


  //TODO: CRIO_TASK_MODULE_REFACTOR
  // 1. Now we want to convert our code into a module, so we will not call it from main anymore.
  //    Copy your code from Module#3 PortfolioManagerApplication#calculateAnnualizedReturn
  //    into #calculateAnnualizedReturn function here and ensure it follows the method signature.
  // 2. Logic to read Json file and convert them into Objects will not be required further as our
  //    clients will take care of it, going forward.

  // Note:
  // Make sure to exercise the tests inside PortfolioManagerTest using command below:
  // ./gradlew test --tests PortfolioManagerTest

  //CHECKSTYLE:OFF




  private Comparator<AnnualizedReturn> getComparator() {
    return Comparator.comparing(AnnualizedReturn::getAnnualizedReturn).reversed();
  }

  //CHECKSTYLE:OFF

  // TODO: CRIO_TASK_MODULE_REFACTOR
  //  Extract the logic to call Tiingo third-party APIs to a separate function.
  //  Remember to fill out the buildUri function and use that.


  public List<Candle> getStockQuote(String symbol, LocalDate from, LocalDate to)  throws JsonProcessingException {
    try {
      return stockQuotesService.getStockQuote(symbol, from, to);
  } catch (StockQuoteServiceException e) {
      e.printStackTrace(); // or rethrow as runtime
      return Collections.emptyList(); // or handle gracefully
  }
  
  }


  @Override
  public List<AnnualizedReturn> calculateAnnualizedReturn(List<PortfolioTrade> trades, LocalDate endDate) throws JsonProcessingException
           {
  
      List<AnnualizedReturn> returns = new ArrayList<>();
  
      for (PortfolioTrade trade : trades) {
          List<Candle> candles = getStockQuote(trade.getSymbol(), trade.getPurchaseDate(), endDate);
  
          if (candles == null || candles.isEmpty()) {
              throw new IllegalArgumentException("No data for symbol: " + trade.getSymbol());
          }
  
          double buyPrice = candles.get(0).getOpen();
          double sellPrice = candles.get(candles.size() - 1).getClose();
  
          AnnualizedReturn annualizedReturn = PortfolioManagerApplication.calculateAnnualizedReturns(
              endDate, trade, buyPrice, sellPrice
          );
  
          returns.add(annualizedReturn);
      }
  
      returns.sort(Comparator.comparing(AnnualizedReturn::getAnnualizedReturn).reversed());
      return returns;
  }
  


public List<Candle> fetchCandles(PortfolioTrade trade, LocalDate endDate) {
    try {
        return PortfolioManagerApplication.fetchCandles(trade, endDate, token);
    } catch (JsonProcessingException e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
    } // static call hidden here
    return null;
}

}
