
package com.crio.warmup.stock.portfolio;

import com.crio.warmup.stock.PortfolioManagerApplication;
import com.crio.warmup.stock.quotes.StockQuotesService;
import org.springframework.web.client.RestTemplate;

public class PortfolioManagerFactory {

  public static PortfolioManager getPortfolioManager(RestTemplate restTemplate) {  
    return new PortfolioManagerImpl(restTemplate);
  } 
  
  // TODO: CRIO_TASK_MODULE_REFACTOR
  //  Implement the method to return new instance of PortfolioManager.
  //  Remember, pass along the RestTemplate argument that is provided to the new instance.  

public static PortfolioManager getPortfolioManager(String provider, RestTemplate restTemplate) {    
  return new PortfolioManagerImpl(provider , restTemplate);
}


public static PortfolioManager getPortfolioManager(StockQuotesService stockQuotesService) {    
  return new PortfolioManagerImpl(stockQuotesService);  
}


}
