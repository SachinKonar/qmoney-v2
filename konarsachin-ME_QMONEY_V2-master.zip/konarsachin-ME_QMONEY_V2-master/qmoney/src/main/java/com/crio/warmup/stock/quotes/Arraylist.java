package com.crio.warmup.stock.quotes;

public class Arraylist {

}
