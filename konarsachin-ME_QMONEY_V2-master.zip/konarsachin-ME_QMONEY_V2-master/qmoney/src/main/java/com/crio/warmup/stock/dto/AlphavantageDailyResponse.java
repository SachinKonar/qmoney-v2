package com.crio.warmup.stock.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AlphavantageDailyResponse {

  @JsonProperty("Time Series (Daily)")
  private Map<String, Map<String, String>> timeSeriesDaily = new HashMap<>();

  public Map<LocalDate, AlphavantageCandle> getCandles() {
    Map<LocalDate, AlphavantageCandle> candles = new HashMap<>();

    System.out.println("📦 Parsing candles from raw data...");
    for (Map.Entry<String, Map<String, String>> entry : timeSeriesDaily.entrySet()) {
      String dateStr = entry.getKey();
      Map<String, String> values = entry.getValue();

      System.out.println("📥 Handling raw entry: \"" + dateStr + "\"");

      try {
        String trimmedDate = dateStr.trim();

        if (!trimmedDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
          System.out.println("🚫 Invalid date key — skipped: \"" + trimmedDate + "\"");
          continue;
        }

        LocalDate date = LocalDate.parse(trimmedDate);
        System.out.println("🧠 Parsed LocalDate: " + date);

        AlphavantageCandle candle = new AlphavantageCandle();
        candle.setOpen(Double.parseDouble(values.get("1. open")));
        candle.setHigh(Double.parseDouble(values.get("2. high")));
        candle.setLow(Double.parseDouble(values.get("3. low")));
        candle.setClose(Double.parseDouble(values.get("4. close")));

        if ("2019-01-04".equals(trimmedDate)) {
          System.out.println("🎯 TEST OVERRIDE: Setting candle.getDate() = null for 2019-01-04");
          //candle.setDate(null);
          candle.setDate(date);
        } else {
          candle.setDate(date);
        }

        candles.put(date, candle);
        System.out.printf("✅ Stored candle for %s → getDate(): %s | Open: %.2f | Close: %.2f | Hash: %d%n",
            date,
            (candle.getDate() != null ? candle.getDate().toString() : "null"),
            candle.getOpen(),
            candle.getClose(),
            System.identityHashCode(candle)
        );

      } catch (Exception e) {
        System.out.println("❌ Exception while processing key: \"" + dateStr + "\"");
        e.printStackTrace(System.out);
      }
    }

    System.out.println("📊 Total candles parsed: " + candles.size());
    return candles;
  }
}
