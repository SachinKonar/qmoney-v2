package com.crio.warmup.stock;

import com.crio.warmup.stock.dto.*;
import com.crio.warmup.stock.log.UncaughtExceptionHandler;
import com.crio.warmup.stock.portfolio.PortfolioManager;
import com.crio.warmup.stock.portfolio.PortfolioManagerFactory;
import com.crio.warmup.stock.util.AnnualizedReturnComparator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.web.client.RestTemplate;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class PortfolioManagerApplication {

  private static final String token = "15c8a42db531df551652a41ddee076de37e348f2";

  public static String getToken() {
    return token;
  }


  public static List<String> mainReadQuotes(String[] args) throws IOException, URISyntaxException {
    String filename = args[0];
    List<PortfolioTrade> trades = readTradesFromJson(filename);
    LocalDate endDate = LocalDate.parse(args[1]);

    List<TotalReturnsDto> dtos = new ArrayList<>();

    for (PortfolioTrade trade : trades) {
      if (endDate.isBefore(trade.getPurchaseDate())) {
        throw new RuntimeException("End date is before purchase date.");
      }
      List<Candle> candles = fetchCandles(trade, endDate, token);
      Double priceEndOfDate = getClosingPriceOnEndDate(candles);
      TotalReturnsDto dto = new TotalReturnsDto(trade.getSymbol(), priceEndOfDate);
      dtos.add(dto);
    }

    return dtos.stream()
        .sorted(Comparator.comparing(TotalReturnsDto::getClosingPrice))
        .map(TotalReturnsDto::getSymbol)
        .collect(Collectors.toList());
  }

  public static Double getClosingPriceOnEndDate(List<Candle> candles) {
    return candles.get(candles.size()-1).getClose();
  }

  public static List<AnnualizedReturn> mainCalculateSingleReturn(String[] args)
      throws IOException, URISyntaxException {
    List<PortfolioTrade> trades = readTradesFromJson(args[0]);
    LocalDate endDate = LocalDate.parse(args[1]);
    List<AnnualizedReturn> annualizedReturns = new ArrayList<>();

    for (PortfolioTrade trade : trades) {
      List<Candle> candles = fetchCandles(trade, endDate, token);
      AnnualizedReturn annualizedReturn = calculateAnnualizedReturns(
          endDate, trade,
          getOpeningPriceOnStartDate(candles),
          getClosingPriceOnEndDate(candles)
      );
      annualizedReturns.add(annualizedReturn);
    }

    annualizedReturns.sort(new AnnualizedReturnComparator());
    return annualizedReturns;
  }

  public static Double getOpeningPriceOnStartDate(List<Candle> candles) {
    return candles.get(0).getOpen();
  }

  public static AnnualizedReturn calculateAnnualizedReturns(LocalDate endDate, PortfolioTrade trade,
                                                            Double buyPrice, Double sellPrice) {
    Double buyValue = trade.getQuantity() * buyPrice;
    Double sellValue = trade.getQuantity() * sellPrice;
    Double totalReturn = (sellValue - buyValue) / buyValue;
    long totalNoDays = ChronoUnit.DAYS.between(trade.getPurchaseDate(), endDate);
    Double totalNoYears = (double) totalNoDays / 365;
    Double annualReturn = Math.pow(1 + totalReturn, 1.0 / totalNoYears) - 1;
    
    return new AnnualizedReturn(trade.getSymbol(), annualReturn, totalReturn);
  }

  public static List<Candle> fetchCandles(PortfolioTrade trade, LocalDate endDate, String token)
      throws JsonProcessingException {
    RestTemplate restTemplate = new RestTemplate();
    String url = prepareUrl(trade, endDate, token);
    TiingoCandle[] candles = restTemplate.getForObject(url, TiingoCandle[].class);
    return Arrays.asList(candles);
  }

  public static List<PortfolioTrade> readTradesFromJson(String filename)
      throws IOException, URISyntaxException {
    File file = resolveFileFromResources(filename);
    ObjectMapper mapper = getObjectMapper();
    return Arrays.asList(mapper.readValue(file, PortfolioTrade[].class));
  }

  public static String prepareUrl(PortfolioTrade trade, LocalDate endDate, String token) {
    return String.format(
        "https://api.tiingo.com/tiingo/daily/%s/prices?startDate=%s&endDate=%s&token=%s",
        trade.getSymbol(), trade.getPurchaseDate(), endDate, token
    );
  }

  private static File resolveFileFromResources(String filename) throws URISyntaxException {
    ClassLoader loader = Thread.currentThread().getContextClassLoader();
    URL resource = loader.getResource(filename);
    if (resource == null) {
      File fallback = new File("src/test/resources/" + filename);
      if (fallback.exists()) return fallback;
      throw new IllegalArgumentException("File not found: " + filename);
    }
    return new File(resource.toURI());
  }

  private static ObjectMapper getObjectMapper() {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    return mapper;
  }

  private static void printJsonObject(Object object) throws JsonProcessingException {
    String objectToJson = getObjectMapper().writeValueAsString(object);
    System.out.println(objectToJson);
  }

  public static List<String> mainReadFile(String[] args) throws IOException, URISyntaxException {
    if (args.length < 2) {
      List<PortfolioTrade> trades = readTradesFromJson(args[0]);
      List<String> symbols = new ArrayList<>();
      for (PortfolioTrade trade : trades) {
        symbols.add(trade.getSymbol());
      }
      return symbols;
    }
    return mainReadQuotes(args);
  }

  public static List<AnnualizedReturn> mainCalculateReturnsAfterRefactor(String[] args)
      throws Exception {
    String file = args[0];
    LocalDate endDate = LocalDate.parse(args[1]);
    String contents = readFileAsString(file);
    ObjectMapper objectMapper = getObjectMapper();
    List<PortfolioTrade> portfolioTrades = Arrays.asList(objectMapper.readValue(contents, PortfolioTrade[].class));

    PortfolioManager portfolioManager = PortfolioManagerFactory.getPortfolioManager(new RestTemplate());
    return portfolioManager.calculateAnnualizedReturn(portfolioTrades, endDate);
  }

    public static void main(String[] args) throws Exception {
    Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler());
    ThreadContext.put("runId", UUID.randomUUID().toString());

    // Replace with desired entry point
    printJsonObject(mainCalculateReturnsAfterRefactor(args));
    // printJsonObject(mainReadQuotes(new String[]{"trades.json", "2019-12-12"}));
  }

  private static String readFileAsString(String filename) throws IOException, URISyntaxException {
    File file = resolveFileFromResources(filename);
    return new String(Files.readAllBytes(Paths.get(file.toURI())));
  }

  public static List<String> debugOutputs() {
    String valueOfArgument0 = "assessments/trades.json";
    String resultOfResolveFilePathArgs0 =
        "/home/crio-user/workspace/konarsachin-ME_QMONEY_V2/qmoney/bin/test/assessments/trades.json";
    String toStringOfObjectMapper = "com.fasterxml.jackson.databind.ObjectMapper@1573f9fc";
    String functionNameFromTestFileInStackTrace = "ModuleOneTest.mainReadFile()";
    String lineNumberFromTestFileInStackTrace = "19";

    return Arrays.asList(
        valueOfArgument0,
        resultOfResolveFilePathArgs0,
        toStringOfObjectMapper,
        functionNameFromTestFileInStackTrace,
        lineNumberFromTestFileInStackTrace
    );
  }
}
