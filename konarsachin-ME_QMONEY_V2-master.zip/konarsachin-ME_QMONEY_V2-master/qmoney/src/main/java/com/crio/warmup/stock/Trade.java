package com.crio.warmup.stock;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Trade {
    private String symbol;

    // Getter
    public String getSymbol() {
        return symbol;
    }

    //knjknkjn
    // Setter
    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    // Optional: Override toString() for debugging purposes
    @Override
    public String toString() {
        return "Trade{symbol='" + symbol + "'}";
    }
}