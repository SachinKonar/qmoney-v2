
package com.crio.warmup.stock.dto;
@SpringBootApplication
public class AnnualizedReturn {

  private final String symbol;
  private final Double annualizedReturn;
  private final Double totalReturns;

  public static void main(String[] args) {
    SpringApplication.run(AnnualReturnApplication.class, args);
}
  public AnnualizedReturn(String symbol, Double annualizedReturn, Double totalReturns) {
    this.symbol = symbol;
    this.annualizedReturn = annualizedReturn;
    this.totalReturns = totalReturns;
  }

  public String getSymbol() {
    return symbol;
  }

  public Double getAnnualizedReturn() {
    //if get annualized return is null return that statement to avoid an error
    return annualizedReturn;
  }

  public Double getTotalReturns() {
    return totalReturns;
  }
}
